<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'wordpress' );

/** Database password */
define( 'DB_PASSWORD', 'wordpress_password' );

/** Database hostname */
define( 'DB_HOST', 'bd_wp' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ']IXq2w3k@v3R%f1u82Wx4#T1dQynR~-ZwaML(jfTBQiN =tUw.mH51F`=6wRPBcb' );
define( 'SECURE_AUTH_KEY',  '?6Qf8-|*we@FChG6l1b/)P*ObG4?< <tuWscdB3Ffq&ML$||A4R_h0q]V1^$sffp' );
define( 'LOGGED_IN_KEY',    '6)EuT.;kX`1;2R)WH6hd%<xv$iXd|<!.ju1AkUS&p<l({NS^B1|^6+)9cwNpPo>D' );
define( 'NONCE_KEY',        '1&+P}e>Y1,`uR?X_jrj65j$?a`U0@~._HP;sB{c@0p$}MKGxyib-}-JBw)Y|)(FJ' );
define( 'AUTH_SALT',        '4gJl)sI}m>PSfUD!wdWs<tWc/PzBca?bD})UZ7<$@DPjC*g&&3f)O=<W*jGqeqQy' );
define( 'SECURE_AUTH_SALT', '%tw2Y41q}o7$ $)!mg@.yLjR}Zs7DXo>ttJqZp`?tKZpl0$g>AM8h(<h6]K-l560' );
define( 'LOGGED_IN_SALT',   ',VVBG(Zho)^vXJV7)T<M{Eo%^BPcw91x%.$lwv0T!^Sx]0dr<WY=HJNi_MtgZ!E_' );
define( 'NONCE_SALT',       'nMkPCse.=3V^g[3y[(SYZUH016$qGO0Pw{Go>9w[*;SX~:d(AYat_(Ig/0]FDq=%' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
